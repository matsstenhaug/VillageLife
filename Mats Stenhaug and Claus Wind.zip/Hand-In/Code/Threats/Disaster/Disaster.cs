using UnityEngine;
using System.Collections;

public class Disaster : MonoBehaviour
{

	/*
	 * SeverityOfPeopleHit
	 * Lethality
	 * ProbabilityOfOcurrance
	 * Duration
	 * --Seasonal -- Triggerable--
	 */

	// Use this for initialization
	void Start ()
	{
	
	}
	
	// Update is called once per frame
	void Update ()
	{
	
	}
}

